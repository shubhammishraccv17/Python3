def mutate_string(string, position, character):
    str1=string[0:position]
    str2=string[position+1: ]
    str3=str1+character+str2

    return str3


if __name__ == '__main__':
    s = input()
    i, c = input().split()
    s_new = mutate_string(s, int(i), c)
    print(s_new)